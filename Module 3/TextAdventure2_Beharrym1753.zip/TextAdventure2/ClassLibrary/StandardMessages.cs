﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 2/27/2020
 * CSC 153
 * Mathias Beharry
 * Pass 2 of semester long project text adventure
 **/

namespace ClassLibrary
{
    public static class StandardMessages                //StandardMessages to display the menu
    {
        public static string Menu()
        {
            Console.WriteLine("Please pick a number");
            Console.WriteLine("1. Move North");
            Console.WriteLine("2. Move South");
            Console.WriteLine("3. Attack");
            Console.WriteLine("4. Exit");
            return "-- >#";
        }
    }
}
