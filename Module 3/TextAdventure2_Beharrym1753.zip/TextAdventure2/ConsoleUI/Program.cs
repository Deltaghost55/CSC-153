﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 2/27/2020
 * CSC 153
 * Mathias Beharry
 * Pass 2 of semester long project text adventure
 **/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create variables
            string input;
            string userOption;
            bool exit = false;
            int index = 0;
            int simHitPoint = 20;               //Simulated mob created

            // Created arrays and lists
            string[] ibRooms = new string[5];
            string[] ibWeapons = new string[4];
            string[] ibPotions = new string[2];
            string[] ibTreasures = new string[3];
            List<string> ibItems = new List<string>();
            List<string> ibMobs = new List<string>();

            // Adding elements to arrays and list
            ibRooms = new string[] { "Entrance", "The infinite Mausoleum", "The Bloody Garden", "The Crooked Nest of Sorcery", "The Keep of the Mirrors" };
            ibWeapons = new string[] { "Shadowfeather", "Torchlight", "Frostmetal", "Cometfall" };
            ibPotions = new string[] { "Flask of Speed", "Draught of Fury" };
            ibTreasures = new string[] { "Lesser Chest", "Common Chest", "Greater Chest" };
            ibItems.Add("Circlet of Youth");
            ibItems.Add("Urn of Lightning");
            ibItems.Add("Jar of Revival");
            ibItems.Add("Boots of Storms");
            ibMobs.Add("Cave Wolf");
            ibMobs.Add("Spell Wisp");
            ibMobs.Add("Final Hag");
            ibMobs.Add("Arctic Chicken");
            ibMobs.Add("Human Bandit");

            // Sorted weapons alphabetically
            Array.Sort(ibWeapons);

            // Do while loop for menu
            do
            {
                Console.Write(ClassLibrary.StandardMessages.Menu());        //Menu display called from class library
                input = Console.ReadLine();                             //Two input variables so that the user-
                userOption = input.ToLower();                           //input can be translated to lowercase.
                Console.WriteLine("");

                //switch to direct to proper process
                switch (userOption)
                {
                    case "1":
                        MoveNorth(ref index, ref ibRooms);
                        break;
                    case "2":
                        MoveSouth(ref index, ref ibRooms);
                        break;
                    case "3":
                        AttackMob(ref simHitPoint, ref ibMobs);
                        break;
                    case "4":
                        exit = true;
                        Console.WriteLine("");
                        break;
                    default:
                        Console.WriteLine("Please enter a valid number");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }

        public static void MoveNorth(ref int index, ref string[] ibRooms)
        {
            if (index == ibRooms.Length)
            {
                Console.WriteLine("Can't go any furthur!");
                Console.WriteLine($"You are in: {index}. {ibRooms[index - 1]}");            //-1 added to WriteLine so the correct room can display
                Console.WriteLine("");
            }
            else if (index < ibRooms.Length)                                                //else if statement to read index then display the following subscript then add 1 to index
            {
                Console.WriteLine($"You are in: {index + 1}. {ibRooms[index]}");            //1 added to WriteLine so the correct room number can display
                Console.WriteLine("");                                                      //If statement that moves the player North
                index++;
            }
            else                                                                            //Else statement added to end the if statements
            {
                Console.WriteLine("Can't go any furthur!");
            }
        }

        public static void MoveSouth(ref int index, ref string[] ibRooms)
        {
            if (index == 0)                                                                 //Seperate if statement just for index == 0 so the program will display everything correctly
            {
                Console.WriteLine("Can't go any furthur!");
                Console.WriteLine($"You are in: {index + 1}. {ibRooms[0]}");                //The only time this if statement is used is if the user enters-
                Console.WriteLine("");                                                      //2. Move South instead of 1. Move North as their first command
                index++;                                                                     
            }
            else if (index == 1)                                                            //This else if statement is now used as the Can't go any further prompt indefinetly until-
            {                                                                               //the user restarts the program and enters 2. Move South as their first command again
                Console.WriteLine("Can't go any furthur!");
                Console.WriteLine($"You are in: {index}. {ibRooms[0]}");
                Console.WriteLine("");
            }
            else
            {
                index--;
                Console.WriteLine($"You are in: {index}. {ibRooms[index - 1]}");            //Else statement that moves the player South
                Console.WriteLine("");
            }
        }

        public static int AttackMob(ref int simHitPoint, ref List<string> ibMobs)       //ibMobs referenced in to display a mob to the user
        {
            Random r = new Random();
            int ra = r.Next(0, 5);                                                      //Extra randmon generator created to select a random mob from ibMobs-
            string rando = ibMobs[ra];                                                  //however it does generate a random mob every time you attack

            Random rand = new Random();                                                 //Random generator to simulate a D20
            int ran = rand.Next(1, 21);
            Console.WriteLine($"You rolled a: {ran}!");
            Console.WriteLine($"{rando}'s health is: {simHitPoint}.");
            simHitPoint -= ran;
            Console.WriteLine($"{rando}'s health is now: {simHitPoint}.");
            Console.WriteLine("");
            return simHitPoint;
        }
    }
}
