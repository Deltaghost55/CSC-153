﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 2/22/2020
 * CSC 153
 * Mathias Beharry
 * Allows the user to enter the amount of time that an object has fallen and then display the distance the object fell.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool run = true;
            while (run == true)                                                 //Variable assigned to sentry while loop
            {
                double fallenDistance = 0;                                      //Assignment of the final variable to be displayed

                Console.Write("Please enter how long the object has been falling in seconds: ");
                double fallenTime = Convert.ToDouble(Console.ReadLine());       //Converts user input into double and stores it in fallenTime variable

                FallingDistance(fallenTime, ref fallenDistance);                //Call FallingDistance method to perform calculations & reference fallenDistance variable

                Console.Write("Run again? y/n ");
                string input = Console.ReadLine();                              //New variable to ask user if they want to continue the program
                if (input == "n" | input == "N")
                {
                    run = false;
                }
                else
                {
                    continue;
                }
            }
        }

        public static void FallingDistance(double fallenTime, ref double fallenDistance)
        {
            fallenDistance = 0.5 * 9.8*(fallenTime*fallenTime);                 //Falling formula using (fallenTime*fallenTime) as an exponent
            fallenDistance = Math.Round(fallenDistance, 1);                     //Shortening decimal place so it is easy on the eyes
            Console.WriteLine($"The object has fallen {fallenDistance} meters in {fallenTime} seconds.");
            Console.WriteLine();
        }
    }
}
