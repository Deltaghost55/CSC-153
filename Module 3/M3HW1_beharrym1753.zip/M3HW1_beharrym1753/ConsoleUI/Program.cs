﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//2/19/2020
// CSC 153
// Mathias Beharry
// Lets the user enter an items wholesale cost and its markup percentage the displays the item's price.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool run = true;
            // sentry while loop
            while (run == true)
            {
                double retailCost = 0;      //Assign retailCost so it can be plugged into CalculateRetail
                Console.Write("Please enter wholesale cost: $");
                double wholesaleCost = Convert.ToDouble(Console.ReadLine());
                //Getting user input for wholesale cost and markup percentage
                Console.Write("Please enter markup percentage: %");
                double markupPercentage = Convert.ToDouble(Console.ReadLine());

                CalculateRetail(markupPercentage, wholesaleCost, retailCost);   //Call the method CalculateRetail which performs the calculations

                Console.Write("Run again? y/n ");       //End sentry while loop depending on user input
                string input = Console.ReadLine();      //Created new string variable for the sentry input
                if (input == "n" | input == "N")
                {
                    run = false;
                }
                else
                {
                    continue;
                }
            }
        }

        public static void CalculateRetail(double markupPercentage, double wholesaleCost, double retailCost)
        {
            markupPercentage = markupPercentage / 100;      //Backwards calculate the markup percentage into decimal format
            retailCost = wholesaleCost * markupPercentage + wholesaleCost;      //Final calculation to get the item's retail price
            Console.WriteLine($"Your retail price is: ${retailCost}");
            Console.WriteLine();
        }
    }
}
