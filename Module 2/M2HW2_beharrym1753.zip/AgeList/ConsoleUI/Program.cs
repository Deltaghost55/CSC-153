﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            /**
            * 2/9/2020
            * CSC 153
            * Asks the user to input ages then stores ages in a list then displays all of the ages inputted.
            **/


            Console.Write("Would you like to run the program? y/n ");       /** Ask user if they want to run program or not and user responds with y or n **/
            string choice = Console.ReadLine();                             /** Assigns users answer to variable named choice **/

            if (choice == "y" || choice == "Y")                             /** If statement based on if user picked y **/
            {
                Console.Write("How many ages do you want to enter? ");
                int ageCount = Convert.ToInt32(Console.ReadLine());         /** Asks user how many ages and assigns their answer to variable named ageCount
                                                                                and converts input to integer**/

                    List<string> ages = new List<string>();                 /** List declaration and assignment **/
                    int b = 1;                                              /** A count value to put in for loop that tells user what number age their on **/
                    for (int i = 0; i < ageCount; i++)
                    {
                        Console.Write($"Please enter age #{b++}: ");        /** for loop to tell the user to enter more ages **/
                        ages.Add(Console.ReadLine());
                    }

                    foreach (var item in ages)                              /** foreach loop to read values in the list ages **/
                    {
                        Console.WriteLine(item);
                    }
                                                                            /** break command to exit the while loop **/
            }

            if (choice == "n" || choice == "N")
            {
                Console.WriteLine("Goodbye!");                              /** If statement if user picked n then program will say goodbye **/
            }
            Console.ReadLine();
        }
    }
}
