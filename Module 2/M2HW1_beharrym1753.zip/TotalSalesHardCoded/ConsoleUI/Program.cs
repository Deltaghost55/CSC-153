﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            /**
            * 2/9/2020
            * CSC 153
            * Mathias Beharry
            * Uses an array to load specified values then the program reads and displays the values in the console.
            **/

            double[] numbers = new double[] { 1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };      /** Declaring my array and assigning it **/

            foreach (var element in numbers)                                                                        /** foreach loop to read my values **/
            {
                Console.WriteLine(element);                                                                         /** Every pass in the loop writes my values to a new line until 
                                                                                                                        no more values can be writen**/
            }

            Console.ReadLine();                                                                                     /** ReadLine is placed at the end of my program **/
        }
    }
}
