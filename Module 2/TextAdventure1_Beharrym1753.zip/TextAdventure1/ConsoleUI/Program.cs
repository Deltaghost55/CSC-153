﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 2/10/2020
 * CSC 153
 * Mathias Beharry
 * Pass 1 of semester long project text adventure
 **/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create variable for user input and sentry for loop
            string input;
            string userOption;
            bool exit = false;

            // index added as a global variable so it does not reset
            int index = 0;

            // Created arrays and lists
            string[] ibRooms = new string[5];
            string[] ibWeapons = new string[4];
            string[] ibPotions = new string[2];
            string[] ibTreasures = new string[3];
            List<string> ibItems = new List<string>();
            List<string> ibMobs = new List<string>();

            // Adding elements to arrays and list
            ibRooms = new string[] { "Entrance", "The infinite Mausoleum", "The Bloody Garden", "The Crooked Nest of Sorcery", "The Keep of the Mirrors" };
            ibWeapons = new string[] { "Shadowfeather", "Torchlight", "Frostmetal", "Cometfall" };
            ibPotions = new string[] { "Flask of Speed", "Draught of Fury" };
            ibTreasures = new string[] { "Lesser Chest", "Common Chest", "Greater Chest" };
            ibItems.Add("Circlet of Youth");
            ibItems.Add("Urn of Lightning");
            ibItems.Add("Jar of Revival");
            ibItems.Add("Boots of Storms");
            ibMobs.Add("Cave Wolf");
            ibMobs.Add("Spell Wisp");
            ibMobs.Add("Final Hag");
            ibMobs.Add("Arctic Chicken");
            ibMobs.Add("Human Bandit");

            // Sorted weapons alphabetically
            Array.Sort(ibWeapons);

            // Do while loop for menu
            do
            {
                Console.WriteLine("Please pick a number or type n or s to move");
                Console.WriteLine("1. Display Rooms");
                Console.WriteLine("2. Display Weapon");
                Console.WriteLine("3. Display Potion");
                Console.WriteLine("4. Display Treasure");
                Console.WriteLine("5. Display Items");
                Console.WriteLine("6. Display Mobs");
                Console.WriteLine("7. Exit");
                Console.Write("-->#");
                input = Console.ReadLine();     //Two input variables so that the user
                userOption = input.ToLower();   //input can be translated to lowercase.
                Console.WriteLine("");

                //switch to direct to proper process
                switch (userOption)
                {
                    case "1":
                        foreach (var i in ibRooms)
                        {
                            Console.WriteLine(i);
                        }
                        Console.WriteLine("");
                        break;
                    case "2":
                        foreach (var i in ibWeapons)
                        {
                            Console.WriteLine(i);
                        }
                        Console.WriteLine("");
                        break;
                    case "3":
                        foreach (var i in ibPotions)
                        {
                            Console.WriteLine(i);
                        }
                        Console.WriteLine("");
                        break;
                    case "4":
                        foreach (var i in ibTreasures)
                        {
                            Console.WriteLine(i);
                        }
                        Console.WriteLine("");
                        break;
                    case "5":
                        foreach (var i in ibItems)
                        {
                            Console.WriteLine(i);
                        }
                        Console.WriteLine("");
                        break;
                    case "6":
                        foreach (var i in ibMobs)
                        {
                            Console.WriteLine(i);
                        }
                        Console.WriteLine("");
                        break;
                    case "7":
                        exit = true;
                        Console.WriteLine("");
                        break;
                    case "n":
                        if (index < ibRooms.Length)                                             //if statement to read index then display the following subscript then add 1 to index
                        {
                            index++;
                            Console.WriteLine($"You are in: {ibRooms[index - 1]}");             //-1 added to WL index so program doesn't explode
                            Console.WriteLine("");
                        }
                        else
                        { 
                            Console.WriteLine("Can't go any furthur!");                         //WL so that the user can know if they are up against a wall
                            Console.WriteLine($"You are in: {ibRooms[ibRooms.Length - 1]}");
                            Console.WriteLine("");
                            break;
                        }
                        break;
                    case "s":
                        if (index <= 1)
                        {
                            Console.WriteLine("Can't go any furthur!");
                            Console.WriteLine($"You are in: {ibRooms[0]}");
                            Console.WriteLine("");
                            break;
                        }
                        else
                        {
                            index--;
                            Console.WriteLine($"You are in: {ibRooms[index - 1]}");
                            Console.WriteLine("");
                        }
                        break;
                    default:
                        Console.WriteLine("Please enter a valid number");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }
    }
}
