﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Car
    {
        // Fields
        private string _year;
        private string _make;
        private int _speed;

        // Constructor
        public Car()
        {
            CarYear = "";
            CarMake = "";
            CarSpeed = 0;
        }

        public Car(string year, string make, int speed)
        {
            CarYear = year;
            CarMake = make;
            CarSpeed = speed;
        }

        // Full Property
        public string CarYear
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;
            }
        }

        public string CarMake
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }
        public int CarSpeed
        {
            get
            {
                return _speed;
            }
            set
            {
                _speed = value;
            }
        }

        // Methods
        public int Accelerate()
        {
            return CarSpeed + 5;
        }

        public int Brake()
        {
            return CarSpeed - 5;
        }

    }
}
