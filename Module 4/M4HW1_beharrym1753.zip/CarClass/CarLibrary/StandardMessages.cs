﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public static class StandardMessages
    {
        public static string Menu()
        {
            return "1.Create car\n" +
                   "2.Accelerate\n" +
                   "3.Brake\n" +
                   "4.Exit\n";
        }
        public static string AskUserForCarMake()
        {
            return "Enter Car's Make: ";
        }
        public static string AskUserForCarYear()
        {
            return "Enter Car's Year: ";
        }
    }
}
