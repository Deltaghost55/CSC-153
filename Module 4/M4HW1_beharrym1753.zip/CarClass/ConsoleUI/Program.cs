﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 3/16/2020
 * CSC 153
 * Mathias Beharry
 * Creates a Car object. The application gives the user 4 options, 1. Create car, 2. Accelerate, 3. Brake, 4. Exit.
 * After creating a car object if the user chooses Accelerate or brake, the application displays the car's new speed.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            CarLibrary.Car myCar = new CarLibrary.Car();    // Car object created
            bool exit = false;  // Sentry loop variable

            do // Sentry loop created to keep things going
            {
                Console.WriteLine(CarLibrary.StandardMessages.Menu()); // The menu displayed to the user is stored in the StandardMessages class
                string input = Console.ReadLine();
                
                switch (input) // Switch to direct to proper option
                {
                    case "1":
                        Console.WriteLine("");
                        Console.Write(CarLibrary.StandardMessages.AskUserForCarYear()); // Stored in StandardMessages class
                        myCar.CarYear = Console.ReadLine();
                        Console.Write(CarLibrary.StandardMessages.AskUserForCarMake()); // Same deal, stored in StandardMessages class
                        myCar.CarMake = Console.ReadLine();
                        Console.WriteLine($"You have picked a {myCar.CarYear} {myCar.CarMake}.");
                        Console.WriteLine("");
                        break;
                    case "2":
                        Console.WriteLine("");
                        if (myCar.CarYear == "" && myCar.CarMake == "") // if statement added to tell user if they have a car
                        {
                            Console.WriteLine("Hey! You need a car first!");
                            Console.WriteLine("");
                            break;
                        }
                        myCar.CarSpeed = myCar.Accelerate();
                        Console.WriteLine($"You are going {myCar.CarSpeed} mph");
                        Console.WriteLine("");
                        break;
                    case "3":
                        Console.WriteLine("");
                        if (myCar.CarYear == "" && myCar.CarMake == "") // same if statement as above, added to tell user if they have a car
                        {
                            Console.WriteLine("Hey! You need a car first!");
                            Console.WriteLine("");
                            break;
                        }
                        if (myCar.CarSpeed <= 0) // if statement added if the user tries to slow down while going 0 mph
                        {
                            Console.WriteLine("Cannot go any slower!");
                            Console.WriteLine($"You are going {myCar.CarSpeed} mph");
                        }
                        else
                        {
                            myCar.CarSpeed = myCar.Brake();
                            Console.WriteLine($"You are going {myCar.CarSpeed} mph");
                        }
                        Console.WriteLine("");
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Please enter a valid option!");
                        break;
                }
            } while (exit == false);
        }
    }
}