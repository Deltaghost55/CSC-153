﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailItemClassLibrary;

/**
 * 3/28/2020
 * CSC 153
 * Mathias Beharry
 * The program creates a list of three class objects and 
 * loops through the list, displaying each item on the list.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            List<RetailItem> retailItem = new List<RetailItem>();

            BuildObjects.BuildClassObjects(retailItem);     // Object creation & population is sent to a seperate class,
                                                            // it is placed outside loop so it won't create more objects
            do
            {
                Console.Write(StandardMessages.Menu());

                switch (Console.ReadLine())
                {
                    case "1":
                        Console.WriteLine("");
                        Console.WriteLine(StandardMessages.ShowItemHeader());
                        Console.WriteLine(StandardMessages.ShowItem(retailItem[0]));
                        Console.WriteLine(StandardMessages.ShowItem(retailItem[1]));
                        Console.WriteLine(StandardMessages.ShowItem(retailItem[2]));
                        Console.WriteLine("");
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayChoiceError());
                        break;
                }
            } while (exit == false);
        }
    }
}
