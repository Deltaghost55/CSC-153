﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
    public class StandardMessages
    {
        public static string Menu()
        {
            return "1. View List\n2. Exit\n#";
        }

        public static string ShowItem(RetailItem item)
        {
            return $"{item.ItemDescription}\t\t{item.ItemUnitsOnHand}\t\t{item.ItemPrice}";     // Using tab operator to align the text with its header
        }

        public static string ShowItemHeader()               // Seperate method created for RetailItem header so that each element's property can display properly
        {
            return $"Description\tUnits on Hand\tPrice";   
        }

        public static string DisplayChoiceError()
        {
            return "\nPlease enter a valid option!\n";
        }
    }
}
