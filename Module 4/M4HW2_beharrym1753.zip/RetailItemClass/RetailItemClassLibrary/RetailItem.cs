﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
    public class RetailItem
    {
        // Fields
        private string _description;
        private string _unitsOnHand;
        private string _price;

        // Constructors
        public RetailItem()
        {
            ItemDescription = "";
            ItemUnitsOnHand = "";
            ItemPrice = "";
        }

        public RetailItem(string desc, string units, string price)
        {
            ItemDescription = desc;
            ItemUnitsOnHand = units;
            ItemPrice = price;
        }

        // Full Properties
        public string ItemDescription
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        public string ItemUnitsOnHand
        {
            get
            {
                return _unitsOnHand;
            }
            set
            {
                _unitsOnHand = value;
            }
        }

        public string ItemPrice
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
    }
}
