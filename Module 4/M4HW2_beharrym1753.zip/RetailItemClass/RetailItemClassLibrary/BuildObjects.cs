﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
    public class BuildObjects
    {
        public static void BuildClassObjects(List<RetailItem> classList) // This class is used just to clean up main
        {                                                                // it creates the class objects and 
            RetailItem retailItemObject1 = new RetailItem();             // populates them then adds it to the list.
            RetailItem retailItemObject2 = new RetailItem();
            RetailItem retailItemObject3 = new RetailItem();

            retailItemObject1.ItemDescription = "Jacket";
            retailItemObject1.ItemUnitsOnHand = "12";
            retailItemObject1.ItemPrice = "$59.05";
            classList.Add(retailItemObject1);

            retailItemObject2.ItemDescription = "Jeans";
            retailItemObject2.ItemUnitsOnHand = "40";
            retailItemObject2.ItemPrice = "$34.95";
            classList.Add(retailItemObject2);

            retailItemObject3.ItemDescription = "Shirt";
            retailItemObject3.ItemUnitsOnHand = "20";
            retailItemObject3.ItemPrice = "$24.95";
            classList.Add(retailItemObject3);
        }
    }
}
