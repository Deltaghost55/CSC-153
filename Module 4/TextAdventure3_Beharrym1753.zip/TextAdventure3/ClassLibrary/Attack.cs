﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Attack
    {
        public static int AttackMob(ref int simHitPoint)
        {
            Random r = new Random();                                                 //Random generator to simulate a D20
            int ran = r.Next(1, 21);
            if (simHitPoint > 0)
            {
                Console.WriteLine($"You rolled a: {ran}!");
                Console.WriteLine($"Bad Guy's health is: {simHitPoint}.");
                simHitPoint -= ran;
                Console.WriteLine($"Bad Guy's health is now: {simHitPoint}.");
                Console.WriteLine("");
                if (simHitPoint < 1)
                {
                    Console.WriteLine("Bad Guy Died!\n");
                    simHitPoint = 20;
                }
                else
                {
                    return simHitPoint;
                }
                return simHitPoint;
            }
            else
            {
                simHitPoint = 20;
                return simHitPoint;
            }
        }
    }
}
