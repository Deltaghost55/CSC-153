﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Potion
    {
        // Fields
        private string _potionName;
        private string _potionDesc;

        // Constructors
        public Potion()
        {
            PotionName = "";
            PotionDesc = "";
        }
        public Potion(string potion, string desc)
        {
            PotionName = potion;
            PotionDesc = desc;
        }

        // Full Properties
        public string PotionName
        {
            get
            {
                return _potionName;
            }
            set
            {
                _potionName = value;
            }
        }
        public string PotionDesc
        {
            get
            {
                return _potionDesc;
            }
            set
            {
                _potionDesc = value;
            }
        }

        // Methods
        public static void BuildPotions(Potion[] classList)
        {
            classList[0] = new Potion
            {
                PotionName = "Flask of Speed",
                PotionDesc = "+80 to Agility"
            };
            classList[1] = new Potion
            {
                PotionName = "Draught of Fury",
                PotionDesc = "+50 Physical damage\n+50 defense"
            };
        }
    }
}
