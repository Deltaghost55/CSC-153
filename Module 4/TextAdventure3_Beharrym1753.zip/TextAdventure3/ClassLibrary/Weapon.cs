﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Weapon
    {
        // Fields
        private string _weaponName;
        private string _weaponDesc;
        private int _weaponAttribute;
        private int _weaponDamage;
        private int _weaponAttributeDamage;

        // Constructors
        public Weapon()
        {
            WeaponName = "";
            WeaponDesc = "";
            WeaponAttribute = 0;
            WeaponDamage = 0;
            WeaponAttributeDamage = 0;
        }
        public Weapon(string weapon, string desc, int attribute, int damage, int attributeDamage)
        {
            WeaponName = weapon;
            WeaponDesc = desc;
            WeaponAttribute = attribute;
            WeaponDamage = damage;
            WeaponAttributeDamage = WeaponAttributeDamage;
        }

        // Full Properties
        public string WeaponName
        {
            get
            {
                return _weaponName;
            }
            set
            {
                _weaponName = value;
            }
        }
        public string WeaponDesc
        {
            get
            {
                return _weaponDesc;
            }
            set
            {
                _weaponDesc = value;
            }
        }
        public int WeaponAttribute  // Attributes: 1 = Dark, 2 = Fire, 3 = Ice
        {
            get
            {
                return _weaponAttribute;
            }
            set
            {
                _weaponAttribute = value;
            }
        }
        public int WeaponDamage
        {
            get
            {
                return _weaponDamage;
            }
            set
            {
                _weaponDamage = value;
            }
        }
        public int WeaponAttributeDamage
        {
            get
            {
                return _weaponAttributeDamage;
            }
            set
            {
                _weaponAttributeDamage = value;
            }
        }

        // Methods
        public static void BuildWeapons(Weapon[] classList)
        {
            classList[0] = new Weapon
            {
                WeaponName = "Shadowfeather",
                WeaponDesc = "120 Physical damage +50 Dark damage",
                WeaponAttribute = 1,
                WeaponDamage = 120,
                WeaponAttributeDamage = 50,
            };
            classList[1] = new Weapon
            {
                WeaponName = "Torchlight",
                WeaponDesc = "110 Physical damage +60 Fire damage",
                WeaponAttribute = 2,
                WeaponDamage = 110,
                WeaponAttributeDamage = 60
            };
            classList[2] = new Weapon
            {
                WeaponName = "Frostmetal",
                WeaponDesc = "144 Physical damage +44 Ice damage",
                WeaponAttribute = 3,
                WeaponDamage = 144,
                WeaponAttributeDamage = 44
            };
            classList[3] = new Weapon
            {
                WeaponName = "Cometfall",
                WeaponDesc = "190 Physical damage",
                WeaponAttribute = 0,
                WeaponDamage = 190,
                WeaponAttributeDamage = 0
            };
        }

        // This class method will be used to determine resitance
        public static void DetermineResistance(Weapon[] classList, List<Mob> mobClass)
        {
            int w1 = classList[0].WeaponAttribute;
            int w2 = classList[1].WeaponAttribute;
            int w3 = classList[2].WeaponAttribute;
            int w4 = classList[3].WeaponAttribute;

            int m1 = mobClass[0].MobResist; //2
            int m2 = mobClass[1].MobResist; //0
            int m3 = mobClass[2].MobResist; //1
            int m4 = mobClass[3].MobResist; //3
            int m5 = mobClass[4].MobResist; //-1

            if (w1 == m1 || w1 == m2 || w1 == m3 || w1 == m4 || w1 == m5)
            { classList[0].WeaponAttributeDamage = 0; }
            else if (m5 == -1)
            { classList[0].WeaponAttributeDamage = 0; }
            else 
            { classList[0].WeaponAttributeDamage = classList[0].WeaponAttributeDamage; }

            if (w2 == m1 || w2 == m2 || w2 == m3 || w2 == m4 || w2 == m5)
            { classList[1].WeaponAttributeDamage = 0; }
            else if (m5 == -1)
            { classList[0].WeaponAttributeDamage = 0; }
            else
            { classList[1].WeaponAttributeDamage = classList[1].WeaponAttributeDamage; }

            if (w3 == m1 || w3 == m2 || w3 == m3 || w3 == m4 || w3 == m5)
            { classList[2].WeaponAttributeDamage = 0; }
            else if (m5 == -1)
            { classList[0].WeaponAttributeDamage = 0; }
            else
            { classList[2].WeaponAttributeDamage = classList[2].WeaponAttributeDamage; }

            if (w4 == m1 || w4 == m2 || w4 == m3 || w4 == m4 || w4 == m5)
            { classList[3].WeaponAttributeDamage = 0; }
            else if (m5 == -1)
            { classList[0].WeaponAttributeDamage = 0; }
            else
            { classList[3].WeaponAttributeDamage = classList[3].WeaponAttributeDamage; }
        }
    }
}
