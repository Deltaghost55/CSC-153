﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Room
    {
        // Fields
        private string _roomName;
        private string _roomDesc;
        private string _roomExit;

        // Constructors
        public Room()
        {
            RoomName = "";
            RoomDesc = "";
            RoomExit = "";
        }
        public Room(string room, string desc, string exit)
        {
            RoomName = room;
            RoomDesc = desc;
            RoomExit = exit;
        }

        // Full Property
        public string RoomName
        {
            get
            {
                return _roomName;
            }
            set
            {
                _roomName = value;
            }
        }
        public string RoomDesc
        {
            get
            {
                return _roomDesc;
            }
            set
            {
                _roomDesc = value;
            }
        }
        public string RoomExit
        {
            get
            {
                return _roomExit;
            }
            set
            {
                _roomExit = value;
            }
        }

        // Methods
        public static void BuildRooms(Room[] classList)
        {
            classList[0] = new Room
            {
                RoomName = "Entrance",
                RoomDesc = "The Entrance to Ibrilyn",
                RoomExit = "Exit: The Infinite Mausoleum"
            };
            classList[1] = new Room
            {
                RoomName = "The Infinite Mausoleum",
                RoomDesc = "Looks like a normal mausoleum, pitch black inside, navigating The Infinite Mausoleum\n" +
                "proves difficult because it doesn't seem to end..",
                RoomExit = "Exit: The Bloody Garden"
            };
            classList[2] = new Room
            {
                RoomName = "The Bloody Garden",
                RoomDesc = "There's blood. Everywhere.",
                RoomExit = "Exit: The Crooked Nest of Sorcery"
            };
            classList[3] = new Room
            {
                RoomName = "The Crooked Nest of Sorcery",
                RoomDesc = "The home of sorcerers, a magic battlefield with spells, illusions and traps. \n" +
                "Rumors say the Final Hag dwells in here... Good luck.",
                RoomExit = "Exit: The Keep of the Mirrors"
            };
            classList[4] = new Room
            {
                RoomName = "The Keep of the Mirrors",
                RoomDesc = "A normal room although when striking a mob it might end up just being a mirror.",
                RoomExit = "Exit: Seems to be blocked by a magic barrier"
            };
        }
    }
}
