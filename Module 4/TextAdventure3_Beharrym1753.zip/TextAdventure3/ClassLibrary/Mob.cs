﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Mob
    {
        // Fields
        private string _mobName;
        private string _mobDesc;
        private int _mobResist;
        private int _mobArmor;
        private int _mobHealth;

        // Constructors
        public Mob()
        {
            MobName = "";
            MobDesc = "";
            MobResist = 0;
            MobArmor = 0;
            MobHealth = 0;
        }
        public Mob(string mob, string desc, int resistance, int armor, int health)
        {
            MobName = mob;
            MobDesc = desc;
            MobResist = resistance;
            MobArmor = armor;
            MobHealth = health;
        }

        // Full Properties
        public string MobName
        {
            get
            {
                return _mobName;
            }
            set
            {
                _mobName = value;
            }
        }
        public string MobDesc
        {
            get
            {
                return _mobDesc;
            }
            set
            {
                _mobDesc = value;
            }
        }
        public int MobResist    // MobResist cancels out WeaponAttributeDamage depending on the number assigned. ----Attributes: 1 = Dark, 2 = Fire, 3 = Ice
        {
            get 
            { 
                return _mobResist; 
            }
            set 
            { 
                _mobResist = value; 
            }
        }
        public int MobArmor 
        { 
            get 
            { 
                return _mobArmor; 
            } 
            set 
            { 
                _mobArmor = value; 
            } 
        }
        public int MobHealth
        {
            get
            {
                return _mobHealth;
            }
            set
            {
                _mobHealth = value;
            }
        }

        // Methods
        public static void BuildMobs(List<Mob> classList)
        {
            Mob mob1 = new Mob();
            Mob mob2 = new Mob();
            Mob mob3 = new Mob();
            Mob mob4 = new Mob();
            Mob mob5 = new Mob();



            mob1.MobName = "Cave Wolf";
            mob1.MobDesc = "400 HP 80 Armor";
            mob1.MobResist = 2;
            mob1.MobArmor = 80;
            mob1.MobHealth = 400;
            classList.Add(mob1);

            mob2.MobName = "Spell Wisp";
            mob2.MobDesc = "200 HP 20 Armor";
            mob2.MobResist = 0;
            mob2.MobArmor = 20;
            mob2.MobHealth = 200;
            classList.Add(mob2);

            mob3.MobName = "Human Bandit";
            mob3.MobDesc = "150 HP 100 Armor";
            mob3.MobResist = 1;
            mob3.MobArmor = 100;
            mob3.MobHealth = 150;
            classList.Add(mob3);

            mob4.MobName = "Arctic Chicken";
            mob4.MobDesc = "500 HP 50 Armor";
            mob4.MobResist = 3;
            mob4.MobArmor = 50;
            mob4.MobHealth = 500;
            classList.Add(mob4);

            mob5.MobName = "Final Hag";
            mob5.MobDesc = "1000 HP 1000 Armor";
            mob5.MobResist = -1;
            mob5.MobArmor = 1000;
            mob5.MobHealth = 1000;
            classList.Add(mob5);
        }
    }
}
