﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Item
    {
        // Fields
        private string _itemName;
        private string _itemDesc;

        // Constructors
        public Item()
        {
            ItemName = "";
        }
        public Item(string item, string desc)
        {
            ItemName = item;
            ItemDesc = desc;
        }

        // Full Property
        public string ItemName
        {
            get
            {
                return _itemName;
            }
            set
            {
                _itemName = value;
            }
        }
        public string ItemDesc
        {
            get
            {
                return _itemDesc;
            }
            set
            {
                _itemDesc = value;
            }
        }

        // Methods
        public static void BuildItems(List<Item> classList)
        {
            Item item1 = new Item();
            Item item2 = new Item();
            Item item3 = new Item();
            Item item4 = new Item();

            item1.ItemName = "Circlet of Youth";
            item1.ItemDesc = "+10 to Charisma";
            classList.Add(item1);

            item2.ItemName = "Urn of Lightning";
            item2.ItemDesc = "Deals 80 Lightning damage";
            classList.Add(item2);

            item3.ItemName = "Jar of Revival";
            item3.ItemDesc = "Revives from death, otherwise fully heals target";
            classList.Add(item3);

            item4.ItemName = "Boots of Storms";
            item4.ItemDesc = "+15 to Agility";
            classList.Add(item4);
        }
    }
}
