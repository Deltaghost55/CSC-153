﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Treasure
    {
        // Fields
        private string _treasureName;
        private string _treasureDesc;

        // Constructors
        public Treasure()
        {
            TreasureName = "";
            TreasureDesc = "";
        }
        public Treasure(string treasure, string desc)
        {
            TreasureName = treasure;
            TreasureDesc = desc;
        }

        // Full Properties
        public string TreasureName
        {
            get
            {
                return _treasureName;
            }
            set
            {
                _treasureName = value;
            }
        }
        public string TreasureDesc
        {
            get
            {
                return _treasureDesc;
            }
            set
            {
                _treasureDesc = value;
            }
        }

        // Methods
        public static void BuildTreasures(Treasure[] classList)
        {
            classList[0] = new Treasure
            {
                TreasureName = "Lesser Chest",
                TreasureDesc = "Rarity level 1"
            };
            classList[1] = new Treasure
            {
                TreasureName = "Common Chest",
                TreasureDesc = "Rarity level 2"
            };
            classList[2] = new Treasure
            {
                TreasureName = "Greater Chest",
                TreasureDesc = "Rarity level 3"
            };
        }
    }
}
