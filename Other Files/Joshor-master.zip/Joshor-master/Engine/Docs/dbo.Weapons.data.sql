INSERT INTO [dbo].[Weapons] ([Id], [Name], [Desc], [Damage], [Cost], [Type]) VALUES (101, N'Club', N'A short stock', N'1d6', 100, N'Blunt')
INSERT INTO [dbo].[Weapons] ([Id], [Name], [Desc], [Damage], [Cost], [Type]) VALUES (102, N'Dagger', N'a small piece of sharp metal', N'1d4', 50, N'Pierce')
INSERT INTO [dbo].[Weapons] ([Id], [Name], [Desc], [Damage], [Cost], [Type]) VALUES (103, N'Falchion', N'Sword', N'1d8', 200, N'Slash')
