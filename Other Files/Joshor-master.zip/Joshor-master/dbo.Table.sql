﻿CREATE TABLE [dbo].[Weapons]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NCHAR(10) NULL, 
    [Desc] NCHAR(10) NULL, 
    [Damage] NCHAR(10) NULL, 
    [Cost] NCHAR(10) NULL
)
