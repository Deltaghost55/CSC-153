﻿insert into Mobs 
Values(1,'Goblin',135,16,6,'1d4','+1','Ugly')
