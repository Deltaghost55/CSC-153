﻿using System;
using System.ComponentModel;
using System.Linq;
using System.IO;
using System.Timers;


namespace JosherConsole
{
    public class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
