﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21220TEST
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(World.StandardMessages.Menu());
            Console.WriteLine(World.StandardMessages.WentNorth());
            Console.WriteLine(World.StandardMessages.WentSouth());
            Console.ReadLine();
        }
    }
}
