﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    public static class StandardMessages
    {
        public static string Menu()
        {
            return "1. Go North \n2. Go South \n3. Exit";
        }

        public static string WentNorth()
        {
            return "You went North";
        }

        public static string WentSouth()
        {
            return "You went South";
        }
    }
}
