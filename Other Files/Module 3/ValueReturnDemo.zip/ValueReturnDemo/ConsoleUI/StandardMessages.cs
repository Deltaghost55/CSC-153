﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class StandardMessages
    {
        public static void DisplayPromt()
        {
            Console.Write("Your number is - ");
        }
    }
}
