﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ValueReturnLib
{
    public static class Math
    {
        public static int AddNumbers(int input)
        {
            int output = input + 5;

            return SubNumbers(output);
        }
        public static int SubNumbers(int input)
        {
            return input - 5;
        }
    }
}
