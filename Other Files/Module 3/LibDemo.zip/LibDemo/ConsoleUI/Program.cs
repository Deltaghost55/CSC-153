﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(ClassLibrary.StandardMessage.Menu());
            Console.WriteLine(ClassLibrary.StandardMessage.NumberError());
            Console.WriteLine(ClassLibrary.Combat.DetermineHit(14));
            Console.ReadLine();
        }
    }
}
