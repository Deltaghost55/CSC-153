﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Enter employee's name.\n"+
                "2. Enter employee's phone number.\n"+
                "3. Enter employee's age.\n"+
                "4. Display employee's information.\n"+
                "5. Display average age of employees.\n"+
                "6. Exit"+
                "--> ";
        }

        public static string PromptForName()
        {
            return "\nEnter employee's Name -> ";
        }

        public static string PromptForNumber()
        {
            return "\nEnter employee's Phone Number -> ";
        }

        public static string PromptForAge()
        {
            return "\nEnter employee's Age -> ";
        }

        public static string DisplayNumberError()
        {
            return "\nNot a vaild number!\n";
        }

        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index)
        {
            return $"\nEmployee Name - { name[index]}\n"+
                $"Employee Phone - { phone[index]}\n"+
                $"Employee Age - { age[index]}\n";
        }
    }
}
