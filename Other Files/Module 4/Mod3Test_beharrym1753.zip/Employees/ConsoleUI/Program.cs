﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 2/10/2020
 * CSC 153
 * Mathias Beharry
 **/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create variable for user input and sentry for loop
            string input;
            bool exit = false;
            // Create constant Var
            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;

            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            // Do while loop for menu
            do
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                input = Console.ReadLine();

                // Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForName());
                        input = Console.ReadLine();

                        EnterName(ref employeeNames, ref nameIndex, input);

                        break;
                    case "2":
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForNumber());
                        input = Console.ReadLine();

                        EnterPhone(ref employeePhone, ref phoneIndex, input);
                        break;
                    case "3":
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForAge());
                        input = Console.ReadLine();
                        employeeAge = EnterAge(employeeAge, input);
                        break;
                    case "4":
                        DisplayEmpInfoToUser(employeeNames, employeePhone, employeeAge);
                        break;
                    case "5":
                        Console.WriteLine("");
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayNumberError());
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }

        public static void EnterName(ref string[] name, ref int index, string input)
        {
            name[index] = input;
            index++;
            Console.WriteLine("");
        }

        public static void EnterPhone(ref string[] phone, ref int index, string input)
        {
            phone[index] = input;
            index++;
            Console.WriteLine("");
        }

        public static List<int> EnterAge(List<int> empAge, string input)
        {
            int number = 0;
            List<int> age = new List<int>();
            age = empAge;

            if (int.TryParse(input, out number))
            {
                age.Add(number);
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayNumberError());
                Console.WriteLine("");
            }

            return age;
        }

        public static void DisplayEmpInfoToUser(string[] name, string[] phone, List<int> age)
        {
            for (int index = 0; index < age.Count; index++)
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee(name, phone, age, index));
            }
        }
    }
}
