﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerClassLibrary
{
    public class Person
    {
        // Fields
        private string _name;
        private string _address;
        private string _phone;

        // Constructors
        public Person()
        {
            PersonName = "";
            PersonAddress = "";
            PersonPhone = "";
        }

        // Properties
        public string PersonName
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string PersonAddress
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        public string PersonPhone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }

        // Methods
    }
}
