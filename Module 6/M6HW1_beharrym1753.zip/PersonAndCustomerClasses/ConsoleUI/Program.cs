﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonAndCustomerClassLibrary;

/*
 * 4/22/2020
 * CSC 153
 * Mathias Beharry
 * Demonstrates inheritance
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer myCustomer = new Customer(1, "Mathias Beharry", "123 WhichWay Road", "910-420-4200", true);

            Console.WriteLine("Customer Number - {0}\n" +
                "Customer Name - {1}\n" +
                "Customer Address - {2}\n" +
                "Customer PhoneNumber - {3}\n" +
                "Is On MailList - {4}", 
                myCustomer.CustomerNumber, myCustomer.PersonName, myCustomer.PersonAddress, myCustomer.PersonPhone, myCustomer.OnMailingList);

            Console.ReadLine();
        }
    }
}
