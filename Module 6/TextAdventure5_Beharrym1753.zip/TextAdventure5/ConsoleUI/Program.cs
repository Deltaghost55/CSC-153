﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/**
 * 4/23/2020
 * CSC 153
 * Mathias Beharry
 * Pass 4 of semester long project text adventure
 **/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create variables
            string input;
            string userOption;
            bool exit = false;
            bool nExit = false;
            int index = 0;
            int simHitPoint = 20;

            // Created arrays and lists
            List<Player> players = new List<Player>();
            List<Item> ibItems = new List<Item>();
            List<Mob> ibMobs = new List<Mob>();
            Room[] ibRooms = new Room[5];
            Weapon[] ibWeapons = new Weapon[4];
            Treasure[] ibTreasures = new Treasure[3];
            Potion[] ibPotions = new Potion[2];

            // Issue the build command, the population of the arrays and lists are in the specified class, the build for Players is located in the first do while loop
            Item.BuildItems(ibItems);
            Room.BuildRooms(ibRooms);
            Weapon.BuildWeapons(ibWeapons);
            Treasure.BuildTreasures(ibTreasures);
            Potion.BuildPotions(ibPotions);
            Mob.BuildMobs(ibMobs);


            // DetermineResistance is not needed yet becuase mobs are not connected to rooms 
            //Weapon.DetermineResistance(ibWeapons, ibMobs); 
            /*
            * What I'm trying to do with this class method is change WeaponAttributeDamage to 0 based on what mob is active and what resistances they have,
            * currently there is no specific mob object needed so the method just changes all of the WeaponAttribureDamage properties to 0.
            * The way it is now it would still set all of them to 0 even if I had a specific mob to enter.
            */


            //Console.WriteLine(StandardMessages.ShowItem(ibItems[0]));
            //Console.WriteLine(StandardMessages.ShowItem(ibItems[1]));
            //Console.WriteLine(StandardMessages.ShowItem(ibItems[2]));
            //Console.WriteLine(StandardMessages.ShowItem(ibItems[3]));

            //Console.WriteLine(StandardMessages.ShowMob(ibMobs[0]));
            //Console.WriteLine(StandardMessages.ShowMob(ibMobs[1]));
            //Console.WriteLine(StandardMessages.ShowMob(ibMobs[2]));
            //Console.WriteLine(StandardMessages.ShowMob(ibMobs[3]));
            //Console.WriteLine(StandardMessages.ShowMob(ibMobs[4]));

            //Console.WriteLine(StandardMessages.ShowRoom(ibRooms[0]));
            //Console.WriteLine(StandardMessages.ShowRoom(ibRooms[1]));
            //Console.WriteLine(StandardMessages.ShowRoom(ibRooms[2]));
            //Console.WriteLine(StandardMessages.ShowRoom(ibRooms[3]));
            //Console.WriteLine(StandardMessages.ShowRoom(ibRooms[4]));

            //Console.WriteLine(StandardMessages.ShowWeapon(ibWeapons[0]));
            //Console.WriteLine(StandardMessages.ShowWeapon(ibWeapons[1]));
            //Console.WriteLine(StandardMessages.ShowWeapon(ibWeapons[2]));
            //Console.WriteLine(StandardMessages.ShowWeapon(ibWeapons[3]));

            //Console.WriteLine(StandardMessages.ShowTreasure(ibTreasures[0]));
            //Console.WriteLine(StandardMessages.ShowTreasure(ibTreasures[1]));
            //Console.WriteLine(StandardMessages.ShowTreasure(ibTreasures[2]));

            //Console.WriteLine(StandardMessages.ShowPotion(ibPotions[0]));
            //Console.WriteLine(StandardMessages.ShowPotion(ibPotions[1]));


            //Seperate do while loop to display the initial menu
            do
            {
                Console.Write(StandardMessages.InitialMenu());
                input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        BuildPlayer.BuildAPlayer(players);

                        // Display selected player
                        Console.WriteLine("");
                        Console.WriteLine(StandardMessages.ShowPlayer(players[0]));
                        Console.WriteLine("");
                        nExit = true;
                        break;
                    case "2":
                        exit = true;
                        nExit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayChoiceError());
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;
                }
            } while (nExit == false);

            // Do while for Main Menu
            do
            {
                if (input == "1")
                {
                    Console.Write(StandardMessages.Menu());
                    userOption = Console.ReadLine();
                    Console.WriteLine("");
                }
                else
                {
                    userOption = "";
                }

                switch (userOption)
                {
                    case "1":
                        Movement.MoveNorth(ref index, ref ibRooms);
                        break;
                    case "2":
                        Movement.MoveSouth(ref index, ref ibRooms);
                        break;
                    case "3":
                        Attack.AttackMob(ref simHitPoint);
                        break;
                    case "4":
                        exit = true;
                        Console.WriteLine("");
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayChoiceError());
                        Console.WriteLine("");
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }
    }
}
