﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Movement
    {
        public static void MoveNorth(ref int index, ref Room[] ibRooms)
        {
            if (index == ibRooms.Length)
            {
                Console.WriteLine("Can't go any furthur!");
                Console.WriteLine($"You are in: {index}. \n{StandardMessages.ShowRoom(ibRooms[index - 1])}");            //-1 added to WriteLine so the correct room can display
                Console.WriteLine("");
            }
            else if (index < ibRooms.Length)                                                //else if statement to read index then display the following subscript then add 1 to index
            {
                Console.WriteLine($"You are in: {index + 1}. \n{StandardMessages.ShowRoom(ibRooms[index])}");            //1 added to WriteLine so the correct room number can display
                Console.WriteLine("");                                                      //If statement that moves the player North
                index++;
            }
            else                                                                            //Else statement added to end the if statements
            {
                Console.WriteLine("Can't go any furthur!");
            }
        }
        public static void MoveSouth(ref int index, ref Room[] ibRooms)
        {
            if (index == 0)                                                                 //Seperate if statement just for index == 0 so the program will display everything correctly
            {
                Console.WriteLine("Can't go any furthur!");
                Console.WriteLine($"You are in: {index + 1}. \n{StandardMessages.ShowRoom(ibRooms[0])}");                //The only time this if statement is used is if the user enters-
                Console.WriteLine("");                                                      //2. Move South instead of 1. Move North as their first command
                index++;
            }
            else if (index == 1)                                                            //This else if statement is now used as the Can't go any further prompt indefinetly until-
            {                                                                               //the user restarts the program and enters 2. Move South as their first command again
                Console.WriteLine("Can't go any furthur!");
                Console.WriteLine($"You are in: {index}. \n{StandardMessages.ShowRoom(ibRooms[0])}");
                Console.WriteLine("");
            }
            else
            {
                index--;
                Console.WriteLine($"You are in: {index}. \n{StandardMessages.ShowRoom(ibRooms[index - 1])}");            //Else statement that moves the player South
                Console.WriteLine("");
            }
        }
    }
}
