﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Potion : Accessories
    {
        // Fields

        // Constructors
        public Potion()
        {
            Name = "";
            Desc = "";
        }
        public Potion(string potion, string desc)
        {
            Name = potion;
            Desc = desc;
        }

        // Full Properties

        // Methods
        public static void BuildPotions(Potion[] classList)
        {
            classList[0] = new Potion
            {
                Name = "Flask of Speed",
                Desc = "+80 to Agility"
            };
            classList[1] = new Potion
            {
                Name = "Draught of Fury",
                Desc = "+50 Physical damage +50 defense"
            };
        }
    }
}
