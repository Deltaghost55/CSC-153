﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Item : Accessories
    {
        // Fields

        // Constructors
        public Item()
        {
            Name = "";
            Desc = "";
        }
        public Item(string item, string desc)
        {
            Name = item;
            Desc = desc;
        }

        // Full Property

        // Methods
        public static void BuildItems(List<Item> classList)
        {
            Item item1 = new Item();
            Item item2 = new Item();
            Item item3 = new Item();
            Item item4 = new Item();

            item1.Name = "Circlet of Youth";
            item1.Desc = "+10 to Charisma";
            classList.Add(item1);

            item2.Name = "Urn of Lightning";
            item2.Desc = "Deals 80 Lightning damage";
            classList.Add(item2);

            item3.Name = "Jar of Revival";
            item3.Desc = "Revives from death, otherwise fully heals target";
            classList.Add(item3);

            item4.Name = "Boots of Storms";
            item4.Desc = "+15 to Agility";
            classList.Add(item4);
        }
    }
}
