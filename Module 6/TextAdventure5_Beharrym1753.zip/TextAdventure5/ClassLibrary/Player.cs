﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Player : LivingObjects
    {
        // Fields
        private string _fName;
        private string _lName;
        private string _password;
        private string _class;
        private string _race;

        // Constructors
        public Player()
        {
            PlayerFirstName = "";
            PlayerLastName = "";
            PlayerPassword = "";
            PlayerClass = "";
            PlayerRace = "";
            Health = 0;
            Armor = 0;
        }
        public Player(string fName, string lName, string pass, string pclass, string race)
        {
            PlayerFirstName = fName;
            PlayerLastName = lName;
            PlayerPassword = pass;
            PlayerClass = pclass;
            PlayerRace = race;
            Health = 0;
            Armor = 0;
        }

        // Full Properties
        public string PlayerFirstName
        {
            get
            {
                return _fName;
            }
            set
            {
                _fName = value;
            }
        }
        public string PlayerLastName
        {
            get
            {
                return _lName;
            }
            set
            {
                _lName = value;
            }
        }
        public string PlayerPassword
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }
        public string PlayerClass
        {
            get
            {
                return _class;
            }
            set
            {
                _class = value;
            }
        }
        public string PlayerRace
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
        public string FullName
        {
            get
            {
                return _fName + " " + _lName;
            }
        }
    }
}
