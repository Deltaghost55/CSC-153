﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Treasure : Accessories
    {
        // Fields

        // Constructors
        public Treasure()
        {
            Name = "";
            Desc = "";
        }
        public Treasure(string treasure, string desc)
        {
            Name = treasure;
            Desc = desc;
        }

        // Full Properties

        // Methods
        public static void BuildTreasures(Treasure[] classList)
        {
            classList[0] = new Treasure
            {
                Name = "Lesser Chest",
                Desc = "Rarity level 1"
            };
            classList[1] = new Treasure
            {
                Name = "Common Chest",
                Desc = "Rarity level 2"
            };
            classList[2] = new Treasure
            {
                Name = "Greater Chest",
                Desc = "Rarity level 3"
            };
        }
    }
}
