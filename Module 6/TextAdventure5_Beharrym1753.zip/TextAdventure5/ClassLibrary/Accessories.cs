﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Accessories
    {
        // Fields

        // Constructors
        public Accessories()
        {
            Name = "";
            Desc = "";
        }
        public Accessories(string name, string desc)
        {
            Name = name;
            Desc = desc;
        }

        // Properties
        public string Name { get; set; }
        public string Desc { get; set; }

        // Methods
    }
}
