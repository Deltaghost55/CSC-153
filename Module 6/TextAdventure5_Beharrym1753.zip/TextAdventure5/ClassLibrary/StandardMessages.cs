﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 2/27/2020
 * CSC 153
 * Mathias Beharry
 * Pass 2 of semester long project text adventure
 **/

namespace ClassLibrary
{
    public static class StandardMessages
    {
        public static string InitialMenu()
        {
            return "Please pick a number\n" +
                "1. Create a player\n" +
                "2. Exit\n" +
                "-- >#";
        }
        public static string Menu()
        {
            return "Please pick a number\n" +
                "1. Move North\n" +
                "2. Move South\n" +
                "3. Attack\n" +
                "4. Exit\n" +
                "-- >#";
        }
        public static string ShowPlayer(Player yourPlayer)
        {
            return $"Player Name - {yourPlayer.FullName}\n" +
                $"Player Class - {yourPlayer.PlayerClass}\n" +
                $"Player Race - {yourPlayer.PlayerRace}";
        }
        public static string ShowItem(Item yourItem)
        {
            return $"Item Name - {yourItem.Name}\n" +
                $"Item Desc - {yourItem.Desc}\n";
        }
        public static string ShowRoom(Room yourRoom)
        {
            return $"Room Name - {yourRoom.Name}\n" +
                $"Room Desc - {yourRoom.Desc}\n" +
                $"Room Exit - {yourRoom.RoomExit}\n";
        }
        public static string ShowWeapon(Weapon yourWeapon)
        {
            return $"Weapon Name - {yourWeapon.Name}\n" +
                $"Weapon Desc - {yourWeapon.Desc}";
        }
        public static string ShowTreasure(Treasure yourTreasure)
        {
            return $"Treasure Name - {yourTreasure.Name}\n" +
                $"Treasure Desc - {yourTreasure.Desc}\n";
        }
        public static string ShowPotion(Potion yourPotion)
        {
            return $"Potion Name - {yourPotion.Name}\n" +
                $"Potion Desc - {yourPotion.Desc}\n";
        }
        public static string ShowMob(Mob yourMob)
        {
            return $"Mob Name - {yourMob.MobName}\n" +
                $"Mob Desc - {yourMob.MobDesc}";
        }
        public static string DisplayChoiceError()
        {
            return "Not a valid choice!";
        }
    }
}
