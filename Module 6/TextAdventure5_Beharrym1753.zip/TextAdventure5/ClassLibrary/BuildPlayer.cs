﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BuildPlayer
    {
        public static void BuildAPlayer(List<Player> inputList)
        {
            Player thisPlayer = new Player();
            bool error = false;

            Console.WriteLine("What is the player's first name ? ");
            Console.Write("=>");
            thisPlayer.PlayerFirstName = Console.ReadLine();

            Console.WriteLine("What is the player's last name ? ");
            Console.Write("=>");
            thisPlayer.PlayerLastName = Console.ReadLine();
            do
            {
                Console.WriteLine("\nPassword must at least contain 1 capital letter, 1 lowercase letter and \n1 special character e.g. (!, @, #, $, %, ^, &, *, ?)\n");
                Console.WriteLine($"What is {thisPlayer.PlayerFirstName}'s password?");
                Console.Write("=>");
                thisPlayer.PlayerPassword = PasswordReq(Console.ReadLine());

                Console.WriteLine(thisPlayer.PlayerPassword);

                if (thisPlayer.PlayerPassword == "\nerror")
                {
                    error = true;
                    Console.WriteLine("\nPassword does not meet the requirements!");
                }
                else
                {
                    error = false;
                }
            } while (error == true);

            Console.WriteLine($"What is {thisPlayer.PlayerFirstName}'s class?");
            Console.Write("=>");
            thisPlayer.PlayerClass = Console.ReadLine();

            Console.WriteLine($"What is {thisPlayer.PlayerFirstName}'s race?");
            Console.Write("=>");
            thisPlayer.PlayerRace = Console.ReadLine();

            inputList.Add(thisPlayer);
        }

        public static string PasswordReq(string input)
        {
            string[] chars = { "!", "@", "#", "$", "%", "^", "&", "*", "?" };

            if (chars.Any(input.Contains) && input.Any(char.IsUpper) && input.Any(char.IsLower))
            {
                return input;
            }
            else
            {
                return "\nerror";
            }
        }
    }
}
