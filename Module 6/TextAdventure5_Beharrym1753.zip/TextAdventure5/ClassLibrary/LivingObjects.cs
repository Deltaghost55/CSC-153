﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class LivingObjects
    {
        // Fields
        private int _hp;
        private int _armor;

        // Constructors
        public LivingObjects()
        {
            Health = 0;
            Armor = 0;
        }
        public LivingObjects(int hp, int armor)
        {
            Health = hp;
            Armor = armor;
        }

        // Properties
        public int Health
        {
            get
            {
                return _hp;
            }
            set
            {
                _hp = value;
            }
        }
        public int Armor
        {
            get
            {
                return _armor;
            }
            set
            {
                _armor = value;
            }
        }

        // Methods
    }
}
