﻿using PreferredCustomerClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class CalculateDiscount
    {
        public static void CalcDisc(List<PreferredCustomer> preferredCustomers, int count, ref double total)
        {
            if (double.TryParse(Console.ReadLine(), out double output))
            {
                preferredCustomers[count].PrefCustSpent += output;
            }
            // if statements to select proper discount level
            if (preferredCustomers[count].PrefCustSpent >= 500 && preferredCustomers[count].PrefCustSpent <= 999)
            {
                Console.WriteLine("5% Discount!");
                preferredCustomers[count].PrefCustDiscount = 0.05;
            }
            else if (preferredCustomers[count].PrefCustSpent >= 1000 && preferredCustomers[count].PrefCustSpent <= 1499)
            {
                Console.WriteLine("6% Discount!");
                preferredCustomers[count].PrefCustDiscount = 0.06;
            }
            else if (preferredCustomers[count].PrefCustSpent >= 1500 && preferredCustomers[count].PrefCustSpent <= 1999)
            {
                Console.WriteLine("7% Discount!");
                preferredCustomers[count].PrefCustDiscount = 0.07;
            }
            else if (preferredCustomers[count].PrefCustSpent >= 2000)
            {
                Console.WriteLine("10% Discount!");
                preferredCustomers[count].PrefCustDiscount = 0.10;
            }

            double discount = output - (output * preferredCustomers[count].PrefCustDiscount); // Raw discount calculation
            total += discount;    // Adding discounted price onto total
            preferredCustomers[count].PrefCustSpent = total;    // Customer expenses is updated with new discounted total
        }
    }
}
