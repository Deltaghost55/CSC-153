﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PreferredCustomerClassLibrary;

namespace ConsoleUI
{
    public class BuildCustomers
    {
        public static void BuildCustomerObjects(List<PreferredCustomer> classlist)
        {
            PreferredCustomer customer = new PreferredCustomer();

            Console.Write(StandardMessages.PromptForCustNumber());
            customer.CustomerNumber = ConvertToInt(Console.ReadLine());

            Console.Write(StandardMessages.PromptForPersonName());
            customer.PersonName = Console.ReadLine();

            Console.Write(StandardMessages.PromptForPersonAddress());
            customer.PersonAddress = Console.ReadLine();

            Console.Write(StandardMessages.PromptForPersonPhone());
            customer.PersonPhone = Console.ReadLine();

            Console.Write(StandardMessages.PromptForCustMailList());
            customer.OnMailingList = ConvertToBool(Console.ReadLine());

            classlist.Add(customer);
        }

        public static int ConvertToInt(string input)
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                Console.WriteLine(StandardMessages.DisplayNumberError());
                Console.Write(StandardMessages.PromptForCustNumber());
                output = ConvertToInt(Console.ReadLine());
                return output;
            }
        }

        public static bool ConvertToBool(string input)  // Switch for ease of use, you only have to type y or n for the bool variable
        {
            bool output = false;

            switch (input.ToLower())
            {
                case "y":
                    output = true;
                    return output;
                case "n":
                    return output;
                default:
                    Console.WriteLine(StandardMessages.DisplayNumberError());
                    Console.Write(StandardMessages.PromptForCustMailList());
                    output = ConvertToBool(Console.ReadLine());
                    return output;
            }
        }
    }
}
