﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PreferredCustomerClassLibrary;

/*
 * 4/23/2020
 * CSC 153
 * Mathias Beharry
 * Calculates customer's discount based on their cumulative purchase.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PreferredCustomer> preferredCustomers = new List<PreferredCustomer>();
            BuildCustomers.BuildCustomerObjects(preferredCustomers);

            bool exit = false;
            int count = 0;
            double total = 0;   // Variable to hold discounted price

            Console.WriteLine("");
            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        Console.Write(StandardMessages.PromptForCustPurchase());
                        CalculateDiscount.CalcDisc(preferredCustomers, count, ref total);   // Discount calculation sent to class
                        Console.WriteLine(StandardMessages.DisplayTotalSpent(preferredCustomers, count));
                        Console.WriteLine("");
                        break;
                    case "2":
                        if (preferredCustomers.Count == 0)
                        {
                            Console.WriteLine(StandardMessages.ListIsEmptyError());
                        }
                        else
                        {
                            Console.WriteLine(StandardMessages.DisplayCustomer(preferredCustomers[count]));
                        }
                        Console.WriteLine("");
                        break;
                    case "3":
                        BuildCustomers.BuildCustomerObjects(preferredCustomers);
                        Console.WriteLine("");
                        count++;
                        total = 0;  // Reset holder variable when creating new customer
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayNumberError());
                        break;
                }
            } while (exit == false);
        }
    }
}
