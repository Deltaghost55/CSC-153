﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Spend $$$.\n" +
                "2. Show Customer Information.\n" +
                "3. Create Customer.\n" +
                "4. Exit\n" +
                "--> ";
        }
        public static string PromptForCustNumber()
        {
            return "Enter Customer's Number -> ";
        }
        public static string PromptForPersonName()
        {
            return "Enter Customer's Name -> ";
        }
        public static string PromptForPersonAddress()
        {
            return "Enter Customer's Address -> ";
        }
        public static string PromptForPersonPhone()
        {
            return "Enter Customer's Phone Number -> ";
        }
        public static string PromptForCustMailList()
        {
            return "Is the Customer on the mailing list? y/n -> ";
        }
        public static string PromptForCustPurchase()
        {
            return "How much was the item? -> ";
        }
        public static string DisplayTotalSpent(List<PreferredCustomer> customer, int count)
        {
            string formattedMoneyValue = String.Format("{0:C}", customer[count].PrefCustSpent);
            return $"Total Spent: {formattedMoneyValue}";
        }
        public static string DisplayCustomer(Customer customer)
        {
            return $"Customer's Number: \t{customer.CustomerNumber} \n" +
                $"Customer's Name: \t{customer.PersonName} \n" +
                $"Customer's Address: \t{customer.PersonAddress}\n" +
                $"Customer's Phone: \t{customer.PersonPhone}\n" +
                $"Is On Mailing List? \t{customer.OnMailingList}";
        }
        public static string DisplayNumberError()
        {
            return "\nNot a vaild number!\n";
        }
        public static string ListIsEmptyError()
        {
            return "Please enter an customer first.";
        }
    }
}
