﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class PreferredCustomer : Customer
    {
        // Fields
        private double _purchases;
        private double _discount;

        // Constructors
        public PreferredCustomer()
        {
            PrefCustSpent = 0;
            PrefCustDiscount = 0;
        }
        public PreferredCustomer(double spent, double discount)
        {
            PrefCustSpent = spent;
            PrefCustDiscount = discount;
        }

        // Properties
        public double PrefCustSpent
        {
            get
            {
                return _purchases;
            }
            set
            {
                _purchases = value;
            }
        }
        public double PrefCustDiscount
        {
            get
            {
                return _discount;
            }
            set
            {
                _discount = value;
            }
        }

        // Methods
    }
}
