﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class Customer : Person
    {
        // Fields
        private int _custNum;
        private bool _onMailList;

        // Constructors
        public Customer()
        {
            CustomerNumber = 0;
            PersonName = "";
            PersonAddress = "";
            PersonPhone = "";
            OnMailingList = false;
        }
        public Customer(int custNum, string name, string address, string phone, bool mailList)
        {
            CustomerNumber = custNum;
            PersonName = name;
            PersonAddress = address;
            PersonPhone = phone;
            OnMailingList = mailList;
        }

        // Properties
        public int CustomerNumber
        {
            get
            {
                return _custNum;
            }
            set
            {
                _custNum = value;
            }
        }
        public bool OnMailingList
        {
            get
            {
                return _onMailList;
            }
            set
            {
                _onMailList = value;
            }
        }

        // Methods
    }
}
